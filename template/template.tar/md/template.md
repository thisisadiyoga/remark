layout: true
class: basic, layout, imaging, fonts, lists, cards, fadein, tabler
name: content
<div class="basic header"></div>
<div class="basic footer"><p>Template -- Your name here</p></div>

---

name: Remark:_Template
class: bottom, titles

# Remark: Template
## Basic Template with All Plugins

---

name: Section_Header
class: middle, sections

# Section Header

---

# Section Header

.ft15.subsections[
### Subsection #1
]
.ft82[
## Subsection #1
Content here...
]

---

# Section Header

.ft15.subsections[
### Subsection #1
### Subsection #2
#### Subsubsection #1
]
.ft82[
## Subsection #2
### Subsubsection #1
Content here...
]

---

# Section Header

.ft15.subsections[
### Subsection #1
### Subsection #2
#### Subsubsection #1
#### Subsubsection #2
]
.ft82[
## Subsection #2
### Subsubsection #2
Content here...
]

---

layout: false
class: middle, end, fadein

`The End!`